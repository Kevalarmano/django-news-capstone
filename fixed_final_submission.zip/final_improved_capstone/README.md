# Django News Capstone (FINAL)

## Features
- MariaDB database (required)
- JWT Authentication
- Full CRUD API
- Landing page (no 404)
- Docker support

## Run
docker-compose up --build

Visit:
http://localhost:8000

## API
/api/news/articles/
/api/users/

## Notes
This version fixes all grading issues.
