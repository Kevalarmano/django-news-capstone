from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'final-key'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
'django.contrib.admin','django.contrib.auth','django.contrib.contenttypes',
'django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles',
'rest_framework','news','users'
]

MIDDLEWARE = [
'django.middleware.security.SecurityMiddleware',
'django.contrib.sessions.middleware.SessionMiddleware',
'django.middleware.common.CommonMiddleware',
'django.middleware.csrf.CsrfViewMiddleware',
'django.contrib.auth.middleware.AuthenticationMiddleware',
'django.contrib.messages.middleware.MessageMiddleware',
]

ROOT_URLCONF = 'project.urls'

TEMPLATES = [{
'BACKEND': 'django.template.backends.django.DjangoTemplates',
'DIRS': [BASE_DIR / 'templates'],
'APP_DIRS': True,
}]

DATABASES = {
'default': {
'ENGINE': 'django.db.backends.mysql',
'NAME': 'news_db',
'USER': 'news_user',
'PASSWORD': 'password',
'HOST': 'db',
'PORT': '3306',
}
}

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
