from django.contrib import admin
from django.urls import path, include
from .landing_view import landing_page

urlpatterns = [
    path('', landing_page, name='home'),
    path('admin/', admin.site.urls),
    path('api/news/', include('news.urls')),
    path('api/users/', include('users.urls')),
]
