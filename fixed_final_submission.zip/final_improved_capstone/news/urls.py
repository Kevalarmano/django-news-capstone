from django.urls import path
from .views import (
    ArticleListCreateView,
    ArticleDetailView,
    CategoryListCreateView,
    CategoryDetailView,
)

urlpatterns = [
    path('articles/', ArticleListCreateView.as_view()),
    path('articles/<int:pk>/', ArticleDetailView.as_view()),
    path('categories/', CategoryListCreateView.as_view()),
    path('categories/<int:pk>/', CategoryDetailView.as_view()),
]